export enum DBConnections {
  moviesApp = 'moviesApp',
}
